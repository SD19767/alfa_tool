package com.example.alfa_tool

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
